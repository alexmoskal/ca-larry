#!/bin/bash

# Script to create certificates from my CA

# Create CA cert/key by doing:
# openssl req -config openssl.my.cnf -new -x509 -extensions v3_ca -keyout private/myca.key -out certs/myca.crt -days 1825

# Set the umask
umask 0277

# Clear the screen
clear

echo "
	Welcome to the Your Cerficate Authority"

echo "
Please enter the user/host this certificate is for"
read RU

while true; do
echo "
	Please select an action below, they are in the order
	necessary to create a new certificate...

1) Generate a Certificate Request, sometimes given by the requestor
2) Sign a Certificate Request 
3) Combine certificate and key into one file, for things like Dovecot
4) Create a deliverable package with key/cert and CA cert 
5) Create client side cert (pkcs12)
6) Revoke a certificate
q) Quit
"
read OPTION

if [[ ${OPTION} = 1 ]]; then
	echo "Generating request for ${RU}...."
	openssl req -config openssl.my.cnf -new -nodes -keyout private/${RU}.key -out csr/${RU}.csr
elif [[ ${OPTION} = 2 ]]; then
	echo "Signing the certificate for ${RU}...."
	openssl ca -config openssl.my.cnf -policy policy_anything -out certs/${RU}.crt -infiles csr/${RU}.csr
elif [[ ${OPTION} = 3 ]]; then
	echo "Combining cert and key for ${RU}...."
	cat certs/${RU}.crt private/${RU}.key > private/${RU}.pem
elif [[ ${OPTION} = 4 ]]; then
	echo "Creating deliverable package for ${RU}...."
	tar cf Deliver/${RU}-package.tar private/${RU}.key certs/${RU}.crt certs/New_CA.crt
elif [[ ${OPTION} = 5 ]]; then
	echo "Create Client side cert..."
	openssl pkcs12 -export -clcerts -in certs/${RU}.crt -inkey private/${RU}.key -out newcerts/${RU}.P12
elif [[ ${OPTION} = 6 ]]; then
	echo "Revoking ${RU}'s certificate..."
	openssl ca -config openssl.my.cnf -revoke certs/${RU}.crt
	echo "Generating new CRL for New_CA"
	openssl ca -config openssl.my.cnf -gencrl -out crl/New_CA.crl
	rm certs/${RU}.crt
	rm private/${RU}.key
else
	echo "
	Goodbye......
	"
	exit
fi

done
